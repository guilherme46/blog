<?php require_once 'vendor/autoload.php'; ?>
<!DOCTYPE html>
<html lang="en" >

<head>
  <meta charset="UTF-8">
  <title>Administração - Site B.V.</title>
  
  
  <link rel='stylesheet' href='https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css'>

      <link rel="stylesheet" href="css/style.css">
      <link rel="stylesheet" href="css/boostrap.min.css">


  
</head>

<body>

  <div id="main-container">
  <!-- Menus -->
  <a id="logo" href="#">BARRIGA VERDE - ADMIN</a>
  <div id="top-menu">
    <div id="top-menu-left">
      <a href="panel.php"><span class="menu-item active">Postagens</span></a>
      <a href="form_cadastro_post.php"><span class="menu-item active">Nova Postagem</a>
    </div>
    <div id="top-menu-right">
     
      <a href="logout.php"><span class="menu-item"><i class="fa fa-sign-out fa-lg" aria-hidden="true"></i></span></a>
    </div>
  </div>
  <!-- End Menus -->

  <!-- Content Area -->
  <div id="content-area">
    
   

  
  
  


    