</div>
  <!-- End Content Area -->
</div>

<div id="credit">
  <p>Painel Administrativo - Site Barriga Verde</p>
</div>

<script  src="js/index.js"></script>

</body>

</html>
